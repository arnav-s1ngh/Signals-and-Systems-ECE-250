n=0:50;
y=ones(1,51)+cos(0.03*pi*n);
stem(n,y);
xlabel("X-Axis");
ylabel("Y-Axis");